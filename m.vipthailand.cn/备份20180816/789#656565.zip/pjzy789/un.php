<?php
require("../config/conn.php");
require("../config/function.php");
$_SESSION["FCWADMINSES"]="";
php_toheader("index.php");
?>
