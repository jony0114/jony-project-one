<div class="treebox">
 <div class="ksm">��滥��</div>
 <ul class="menu">
 
 <li class="level1">
  <a href="javascript:void(0);" class="<? if($leftid==1){?>current <? }?>a1"><em></em>������<i></i></a>
  <ul class="level2" style="display:<? if($leftid==1){?>block;<? }?>">
  <li><a href="adtypeMT.php">ѡ����λ</a></li>
  </ul>
 </li>

 </ul>
</div>
<!--LEFT E-->
<? include("left.php");?>
