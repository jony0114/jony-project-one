<!--����ͷ��B-->
<div class="glotop box">
 <div class="d1"><a href="<?=weburl?>m/"><img src="<?=weburl?>m/img/logo.png" height="30" /></a></div>
 <div class="d2"></div>
 <div class="d3" onclick="gourl('yanshou.php')"><img src="<?=weburl?>m/img/list.png" height="15" /></div>
</div>
<!--��ҳ����ͷ��E-->
<div id="lxwmtxtYJ" style="display:none;"><?=str_replace("<br/>","<span class='hx'></span>",returnonecontrol(5))?></div>