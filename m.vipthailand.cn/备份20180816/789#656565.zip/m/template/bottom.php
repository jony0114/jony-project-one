<div class="bottommain"></div>
<div class="gbottom box">
 <div class="d1" onclick="gourl('<?=weburl?>m/')"><img src="img/nbo1.png" /><br>��ҳ</div>
 <div class="d2"><a href="http://p.qiao.baidu.com/cps/chat?siteId=11294296&userId=20630745" target="_blank"><img src="img/nbo2.png" /><br>������ѯ</a></div>
 <div class="d3" onclick="wxzxopen()"><img src="img/nbo3.png" /><br>΢����ѯ</div>
 <div class="d4"><a href="javascript:void(0);" onclick="telopen()"><img src="img/nbo4.png" /><br>��ѵ绰</a></div>
</div>
<div id="weixinLXYJ" style="display:none;"><?=$rowcontrol[weixin]?></div>