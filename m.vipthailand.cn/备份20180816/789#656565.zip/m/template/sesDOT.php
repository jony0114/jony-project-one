<?
session_start();
$a=$_SESSION[FCWuser];
$b=$_SESSION[FCWuserID];
$_SESSION[FCWuser]=$a;
$_SESSION[FCWuserID]=$b;
?>